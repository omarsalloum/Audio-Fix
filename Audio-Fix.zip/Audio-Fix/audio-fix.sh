#! /bin/bash
# Date: 07/05/2016
sleep 0.25
echo "$( tput setaf 6) 

               ######   ##    ##
              ##    ##   ##  ##
              ##          ####
               ######      ##
                    ##     ##
              ##    ##     ##
               ######      ##
            $( tput setaf 3)Coded By Syrian St0rm$(tput sgr0)
                 $( tput setaf 6)d5@live.se$(tput sgr0)
$(tput sgr0) "
sleep 0.05
echo "$( tput setaf 6) ..........................................................$(tput sgr0)"
echo " "
echo " $( tput setaf 10)[\] Fix Audio Problem in Kali Linux 2016 2.0 [\]$(tput sgr0) "
echo " $( tput setaf 11)[\] Downloading the required files [\]$(tput sgr0)"
sleep 3
apt-get install alsa-base alsa-tools alsa-tools-gui alsa-utils alsa-oss alsamixergui libalsaplayer0
echo " " 
clear
sleep 0.05

cp .bashrc -t /root/
sleep 0.05
echo " "
echo " $( tput setaf 10)<< installed Successfully >>$(tput sgr0) "
echo " $( tput setaf 6)
 .####...######...####...#####...##...##.
 ##........##....##..##..##..##..###.###.
 .####.....##....##..##..#####...##.#.##.
 ...##....##....##..##..##..##..##...##.
 ####.....##.....####...##..##..##...##.$(tput sgr0)"
echo " $( tput setaf 10).......................................
$(tput sgr0)"
